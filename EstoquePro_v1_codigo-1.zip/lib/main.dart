import 'package:flutter/material.dart';

void main() {
  runApp(const EstoqueProApp());
}

class Product {
  String name;
  double cost;
  double price;
  int stock;
  int minStock;

  Product({
    required this.name,
    required this.cost,
    required this.price,
    required this.stock,
    this.minStock = 2,
  });

  double get profit => price - cost;
}

class Sale {
  final Product product;
  final int quantity;
  final DateTime date;

  Sale({
    required this.product,
    required this.quantity,
    required this.date,
  });

  double get total => product.price * quantity;
  double get profit => product.profit * quantity;
}

class EstoqueProApp extends StatelessWidget {
  const EstoqueProApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'EstoquePro',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF061018),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF39F06B),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int selectedIndex = 0;

  final List<Product> products = [
    Product(name: 'Maleta de ferramentas', cost: 15, price: 45, stock: 12),
    Product(name: 'Cabo USB', cost: 8, price: 15, stock: 8),
    Product(name: 'Fone de ouvido', cost: 10, price: 30, stock: 2),
  ];

  final List<Sale> sales = [];

  double get totalSales =>
      sales.fold(0, (sum, sale) => sum + sale.total);

  double get totalProfit =>
      sales.fold(0, (sum, sale) => sum + sale.profit);

  int get lowStock =>
      products.where((p) => p.stock <= p.minStock).length;

  void addProduct() {
    final nameController = TextEditingController();
    final costController = TextEditingController();
    final priceController = TextEditingController();
    final stockController = TextEditingController();
    final minController = TextEditingController(text: '2');

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Adicionar produto'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _field(nameController, 'Nome do produto'),
                _field(costController, 'Preço de custo', number: true),
                _field(priceController, 'Preço de venda', number: true),
                _field(stockController, 'Quantidade em estoque', number: true),
                _field(minController, 'Estoque mínimo', number: true),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () {
                final name = nameController.text.trim();
                final cost = double.tryParse(
                      costController.text.replaceAll(',', '.'),
                    ) ??
                    0;
                final price = double.tryParse(
                      priceController.text.replaceAll(',', '.'),
                    ) ??
                    0;
                final stock = int.tryParse(stockController.text) ?? 0;
                final min = int.tryParse(minController.text) ?? 2;

                if (name.isEmpty || price <= 0) return;

                setState(() {
                  products.add(Product(
                    name: name,
                    cost: cost,
                    price: price,
                    stock: stock,
                    minStock: min,
                  ));
                });
                Navigator.pop(context);
              },
              child: const Text('Salvar'),
            ),
          ],
        );
      },
    );
  }

  static Widget _field(
    TextEditingController controller,
    String label, {
    bool number = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: controller,
        keyboardType:
            number ? const TextInputType.numberWithOptions(decimal: true) : null,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }

  void registerSale(Product product) {
    if (product.stock <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Produto sem estoque.')),
      );
      return;
    }

    int quantity = 1;

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            final total = product.price * quantity;
            final profit = product.profit * quantity;

            return AlertDialog(
              title: Text(product.name),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text('Preço: R\$ ${product.price.toStringAsFixed(2)}'),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        onPressed: quantity > 1
                            ? () => setDialogState(() => quantity--)
                            : null,
                        icon: const Icon(Icons.remove_circle_outline),
                      ),
                      Text(
                        '$quantity',
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      IconButton(
                        onPressed: quantity < product.stock
                            ? () => setDialogState(() => quantity++)
                            : null,
                        icon: const Icon(Icons.add_circle_outline),
                      ),
                    ],
                  ),
                  Text('Venda: R\$ ${total.toStringAsFixed(2)}'),
                  Text(
                    'Lucro: R\$ ${profit.toStringAsFixed(2)}',
                    style: const TextStyle(
                      color: Color(0xFF39F06B),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancelar'),
                ),
                FilledButton(
                  onPressed: () {
                    setState(() {
                      product.stock -= quantity;
                      sales.insert(
                        0,
                        Sale(
                          product: product,
                          quantity: quantity,
                          date: DateTime.now(),
                        ),
                      );
                    });
                    Navigator.pop(context);
                    ScaffoldMessenger.of(this.context).showSnackBar(
                      const SnackBar(content: Text('Venda registrada!')),
                    );
                  },
                  child: const Text('Finalizar venda'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Widget dashboard() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          'EstoquePro',
          style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 4),
        const Text('Mais controle. Mais vendas. Mais lucro.'),
        const SizedBox(height: 20),
        Row(
          children: [
            Expanded(child: _card('Vendas hoje', 'R\$ ${totalSales.toStringAsFixed(2)}', Icons.shopping_cart)),
            const SizedBox(width: 10),
            Expanded(child: _card('Lucro', 'R\$ ${totalProfit.toStringAsFixed(2)}', Icons.trending_up)),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(child: _card('Produtos', '${products.length}', Icons.inventory_2)),
            const SizedBox(width: 10),
            Expanded(child: _card('Estoque baixo', '$lowStock', Icons.warning_amber)),
          ],
        ),
        const SizedBox(height: 18),
        FilledButton.icon(
          onPressed: () {
            if (products.isEmpty) return;
            registerSale(products.first);
          },
          icon: const Icon(Icons.add_shopping_cart),
          label: const Padding(
            padding: EdgeInsets.symmetric(vertical: 14),
            child: Text('Registrar venda'),
          ),
        ),
        const SizedBox(height: 22),
        const Text(
          'Últimas vendas',
          style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        if (sales.isEmpty)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 20),
            child: Text('Nenhuma venda registrada ainda.'),
          )
        else
          ...sales.take(5).map(
                (sale) => ListTile(
                  leading: const CircleAvatar(
                    child: Icon(Icons.sell),
                  ),
                  title: Text(sale.product.name),
                  subtitle: Text('${sale.quantity} unidade(s)'),
                  trailing: Text(
                    'R\$ ${sale.total.toStringAsFixed(2)}',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ),
      ],
    );
  }

  Widget _card(String title, String value, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: const Color(0xFF39F06B)),
            const SizedBox(height: 8),
            Text(title),
            const SizedBox(height: 4),
            Text(
              value,
              style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }

  Widget productsPage() {
    return Scaffold(
      appBar: AppBar(title: const Text('Produtos')),
      floatingActionButton: FloatingActionButton(
        onPressed: addProduct,
        child: const Icon(Icons.add),
      ),
      body: products.isEmpty
          ? const Center(child: Text('Nenhum produto cadastrado.'))
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: products.length,
              itemBuilder: (context, index) {
                final p = products[index];
                final low = p.stock <= p.minStock;

                return Card(
                  child: ListTile(
                    leading: CircleAvatar(
                      child: Icon(low ? Icons.warning : Icons.inventory_2),
                    ),
                    title: Text(p.name),
                    subtitle: Text(
                      'Estoque: ${p.stock}  •  Custo: R\$ ${p.cost.toStringAsFixed(2)}\n'
                      'Venda: R\$ ${p.price.toStringAsFixed(2)}  •  Lucro: R\$ ${p.profit.toStringAsFixed(2)}',
                    ),
                    isThreeLine: true,
                    trailing: IconButton(
                      icon: const Icon(Icons.sell),
                      onPressed: () => registerSale(p),
                    ),
                  ),
                );
              },
            ),
    );
  }

  Widget salesPage() {
    return Scaffold(
      appBar: AppBar(title: const Text('Vendas')),
      body: sales.isEmpty
          ? const Center(child: Text('Nenhuma venda registrada.'))
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: sales.length,
              itemBuilder: (context, index) {
                final sale = sales[index];
                return Card(
                  child: ListTile(
                    title: Text(sale.product.name),
                    subtitle: Text(
                      '${sale.quantity} unidade(s) • ${sale.date.hour.toString().padLeft(2, '0')}:${sale.date.minute.toString().padLeft(2, '0')}',
                    ),
                    trailing: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text('R\$ ${sale.total.toStringAsFixed(2)}'),
                        Text(
                          'Lucro R\$ ${sale.profit.toStringAsFixed(2)}',
                          style: const TextStyle(color: Color(0xFF39F06B)),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }

  Widget reportsPage() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          'Relatórios',
          style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 16),
        _card('Total de vendas', 'R\$ ${totalSales.toStringAsFixed(2)}', Icons.payments),
        _card('Lucro total', 'R\$ ${totalProfit.toStringAsFixed(2)}', Icons.trending_up),
        _card('Quantidade de vendas', '${sales.length}', Icons.receipt_long),
      ],
    );
  }

  Widget currentPage() {
    switch (selectedIndex) {
      case 1:
        return productsPage();
      case 2:
        return salesPage();
      case 3:
        return reportsPage();
      default:
        return dashboard();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: currentPage()),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: (index) {
          setState(() => selectedIndex = index);
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: 'Início'),
          NavigationDestination(icon: Icon(Icons.inventory_2), label: 'Produtos'),
          NavigationDestination(icon: Icon(Icons.sell), label: 'Vendas'),
          NavigationDestination(icon: Icon(Icons.bar_chart), label: 'Relatórios'),
        ],
      ),
    );
  }
}
