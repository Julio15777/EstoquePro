# EstoquePro — versão 1.0

Primeira versão do aplicativo de controle de estoque, vendas e lucro.

## O que já funciona

- Dashboard
- Cadastro de produtos
- Estoque
- Registro de vendas
- Baixa automática no estoque
- Cálculo de venda e lucro
- Histórico de vendas
- Relatório básico

## Importante

Esta primeira versão mantém os dados apenas enquanto o aplicativo está aberto.
Na próxima versão podemos adicionar banco de dados local, para os dados continuarem salvos depois de fechar o app.

## Como abrir

1. Instale Flutter e Android Studio.
2. Abra esta pasta no Android Studio ou VS Code.
3. Execute `flutter pub get`.
4. Conecte um celular Android ou use um emulador.
5. Execute `flutter run`.

Para gerar o APK depois:
`flutter build apk --release`
